library(readr)
library(ggplot2)
library(scales)
library(dplyr)
library(tidyr)

attributions <-read_csv("~/Projects/deep-neural-inspector/experiments/linux_kernel/history/Linux-2017-10-10 20:34:59.413868/attributions_nohead",
                        col_names = FALSE)
colnames(attributions) <- c(
  'char_\t','char_\n','char_\xa9','char_!','char_ ','char_#','char_"','char_%','char_$',
  "char_'",'char_&','char_)','char_(','char_+','char_*','char_-','char_,','char_/',
  'char_.','char_1','char_0','char_3','char_2','char_5','char_4','char_7','char_6',
  'char_9','char_8','char_;','char_:','char_=','char_<','char_?','char_>','char_@',
  'char_[','char_]','char_\\','char__','char_^','char_a','char_`','char_c','char_b',
  'char_e','char_d','char_g','char_f','char_i','char_h','char_k','char_j','char_m','char_l',
  'char_o','char_n','char_q','char_p','char_s','char_r','char_u','char_t','char_w','char_v',
  'char_y','char_x','char_{','char_z','char_}','char_|','char_~','line_pos',
  'dep_()_1','dep_()_2','dep_()_3','dep_()_4','dep_{}_1',
  'dep_{}_2','dep_{}_3','dep_{}_4','dep_{}_5','line_pos','enc_/**/',
  'indent0','indent1','indent2','indent3','indent4','indent5',
  'indent6','indent7','indent8','n_gram_0',
  'n_gram_1','n_gram_2','n_gram_3','n_gram_4','n_gram_5','n_gram_6','n_gram_7',
  'n_gram_8','n_gram_9','n_gram_10','n_gram_11','n_gram_12','n_gram_13','n_gram_14',
  'n_gram_15','n_gram_16','n_gram_17','n_gram_18','n_gram_19','n_gram_20',
  'n_gram_21','n_gram_22','n_gram_23','n_gram_24','n_gram_25','n_gram_26',
  'n_gram_27','n_gram_28','n_gram_29','n_gram_30','n_gram_31','n_gram_32',
  'n_gram_33','n_gram_34','n_gram_35','n_gram_36','n_gram_37','n_gram_38',
  'n_gram_39','n_gram_40','n_gram_41','n_gram_42','n_gram_43','n_gram_44','n_gram_45',
  'n_gram_46','n_gram_47','n_gram_48','n_gram_49'
)

# Gets scores
attributions[['Neuron']] <- factor(0:(nrow(attributions)-1),
                           levels = 0:(nrow(attributions)-1),
                           labels = as.character(0:(nrow(attributions)-1)))
data <- gather(attributions, key='Feature', value='Score', -Neuron)

# Gets selection
data$selected <- ifelse(data$Score > .4, 'X', '')

# Filters
data <- data %>% filter(grepl("char_",Feature)) %>%
                mutate(layer=as.numeric(Neuron) %/% 128) %>% filter(layer==1)
# Plots
p <- ggplot(data, aes(x=Feature, y=Neuron, fill=Score, label=selected)) +
  geom_bin2d(aes='identity') +
  geom_text(color='red') +
  scale_fill_gradient2(midpoint=median(data$Score),
                       low = muted("blue"), mid = "white",high = muted("red"),
                       limits=c(0,NA)) +
  facet_grid(layer~., scales = 'free') +
  theme(axis.text.x = element_text(angle=90))

print(p)
